using UnityEngine;

namespace Unity.MLAgentsExamples
{
    public class Area : MonoBehaviour
    {
        public virtual void ResetArea()
        {
        }
    }
}
